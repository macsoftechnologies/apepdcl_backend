import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class StaffAuthGuard extends AuthGuard('staff-jwt') {}
